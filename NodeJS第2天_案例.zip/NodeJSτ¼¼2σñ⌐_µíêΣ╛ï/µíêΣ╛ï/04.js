/**
 * Created by Danny on 2015/9/20 10:28.
 */
var foo = require("./test/foo.js");

console.log(foo.msg);
console.log(foo.info);
foo.showInfo();